

Just check the checkbox to enable overkill mode, can be toggled on and off.
Detailed settings for overkill mode can obviously be found in the corresponding drop down.
Feel free to suggest additions/fixes/changes you might make with this.

Most of the simple *available* elements can be found in the "Currently Available GUI Element Selector" if they aren't already in the list.
You can add and remove elements from the list and it will be saved, though the default elements will always come back.
NOTE: An element must be loaded for it to show in the list, i.e. the bowgun elements would only be in the selection if you have a bowgun equiped on a quest.
Though they don't neccessarily need to be visible at the time.

NOTE: For some reason the keyboard shortcut UI is different somehow and is NOT in the list with literally every other UI element.
Props if someone can figure that out.

Some sub UI elements arent scalable like some of the health bar stuff.

TIP: If you Ctrl+Click a slider in REF you can manually enter a value.

For more details on subpanels and such please read through this helpful discussion with pictures on github:
https://github.com/BoltManGuy/UI_Scaler/pull/2